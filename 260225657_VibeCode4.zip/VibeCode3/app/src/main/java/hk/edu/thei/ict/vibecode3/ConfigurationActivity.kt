package hk.edu.thei.ict.vibecode3

import android.content.Intent
import android.os.Bundle
import android.widget.Switch
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * ConfigurationActivity 處理 App 的設定，包含音效開關與清除資料。
 */
class ConfigurationActivity : AppCompatActivity() {
    private lateinit var prefs: PrefsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_configuration)
        prefs = PrefsManager(this)

        // 綁定音效開關並設定監聽器
        val switchSound = findViewById<Switch>(R.id.switchSound)
        switchSound.isChecked = prefs.soundEnabled
        switchSound.setOnCheckedChangeListener { _, isChecked ->
            // 當開關切換時，更新儲存在 PrefsManager 的狀態
            prefs.soundEnabled = isChecked
        }

        // 返回按鈕
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnBack).setOnClickListener {
            finish()
        }

        // 清除所有資料按鈕
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnReset).setOnClickListener {
            // 彈出確認視窗，避免誤觸
            AlertDialog.Builder(this)
                .setTitle("確認").setMessage("確定清除所有資料？")
                .setPositiveButton("確定") { _, _ ->
                    prefs.clearAll()
                    startActivity(Intent(this, LoginActivity::class.java))
                    finish()
                }
                .setNegativeButton("取消", null).show()
        }
    }
}