package hk.edu.thei.ict.vibecode3

import android.os.Bundle
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

/**
 * GameActivity 實作猜數字遊戲的邏輯。
 */
class GameActivity : AppCompatActivity() {
    private lateinit var prefs: PrefsManager
    private lateinit var dbHelper: DatabaseHelper

    // 遊戲狀態變數
    private var targetNumber = 0 // 目標答案
    private var attemptCount = 0 // 已猜測次數
    private var isWon = false // 是否已獲勝
    private var minRange = 0 // 提示範圍下限
    private var maxRange = 100 // 提示範圍上限

    // UI 元件
    private lateinit var tvMessage: TextView
    private lateinit var tvRange: TextView
    private lateinit var tvAttempts: TextView
    private lateinit var etGuess: EditText
    private lateinit var btnAction: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game)

        prefs = PrefsManager(this)
        dbHelper = DatabaseHelper(this)

        // 初始化 UI 元件
        tvMessage = findViewById(R.id.tvMessage)
        tvRange = findViewById(R.id.tvRange)
        tvAttempts = findViewById(R.id.tvAttempts)
        etGuess = findViewById(R.id.etGuess)
        btnAction = findViewById(R.id.btnAction)

        resetGame() // 初始化新遊戲

        // 返回按鈕邏輯
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnBack).setOnClickListener {
            if (isWon) {
                finish() // 已經贏了，直接返回
            } else {
                showExitConfirmDialog() // 尚未結束，彈出確認視窗
            }
        }

        // 處理鍵盤上的 Enter / Done 鍵
        etGuess.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) {
                if (!isWon) submitGuess()
                true
            } else false
        }

        // 動作按鈕 (確認 / 再玩一次)
        btnAction.setOnClickListener {
            if (isWon) {
                resetGame()
            } else {
                submitGuess()
            }
        }
    }

    /**
     * 處理玩家提交的猜測數字。
     */
    private fun submitGuess() {
        val inputString = etGuess.text.toString()
        val playerGuess = inputString.toIntOrNull()

        // 驗證輸入
        if (playerGuess == null) {
            tvMessage.text = "請輸入有效的數字！"
            tvMessage.setTextColor(android.graphics.Color.RED)
        } else if (playerGuess !in minRange..maxRange) {
            tvMessage.text = "請輸入 $minRange 到 $maxRange 之間的數字！"
            tvMessage.setTextColor(android.graphics.Color.RED)
        } else {
            // 輸入有效，開始判斷
            tvMessage.setTextColor(android.graphics.Color.parseColor("#333333"))
            attemptCount++

            if (playerGuess == targetNumber) {
                tvMessage.text = "🎉 恭喜猜中！\n總共猜了 $attemptCount 次"
                isWon = true
                endGame()
            } else if (playerGuess < targetNumber) {
                // 猜太小，更新下限
                minRange = maxOf(minRange, playerGuess + 1)
                tvMessage.text = "太小了！再試一次"
            } else {
                // 猜太大，更新上限
                maxRange = minOf(maxRange, playerGuess - 1)
                tvMessage.text = "太大了！再試一次"
            }
            updateUI()
        }
        etGuess.text.clear() // 清空輸入框
    }

    /**
     * 重置遊戲狀態，重新開始。
     */
    private fun resetGame() {
        targetNumber = Random.nextInt(0, 101) // 產生 0~100 的隨機數
        attemptCount = 0
        isWon = false
        minRange = 0
        maxRange = 100

        tvMessage.text = "請輸入 0 到 100 之間的數字："
        tvMessage.setTextColor(android.graphics.Color.parseColor("#333333"))
        etGuess.text.clear()
        etGuess.isEnabled = true
        btnAction.text = "確認"
        updateUI()
    }

    /**
     * 當玩家獲勝時執行。
     */
    private fun endGame() {
        etGuess.isEnabled = false
        btnAction.text = "再玩一次"

        // 更新統計數據
        prefs.gamesPlayed = prefs.gamesPlayed + 1
        prefs.wins = prefs.wins + 1

        // 將紀錄寫入資料庫
        val username = prefs.username ?: "訪客"
        dbHelper.insertGuessRecord(username, targetNumber, attemptCount)

        // 跳出勝利對話框
        AlertDialog.Builder(this)
            .setTitle("🎉 恭喜獲勝！")
            .setMessage("你總共猜了 $attemptCount 次。\n要再玩一局，還是返回上一頁？")
            .setCancelable(false) // 禁止點擊外部關閉
            .setPositiveButton("再玩一次") { _, _ -> resetGame() }
            .setNegativeButton("返回") { _, _ -> finish() }
            .show()
    }

    /**
     * 離開遊戲的確認對話框。
     */
    private fun showExitConfirmDialog() {
        AlertDialog.Builder(this)
            .setTitle("離開遊戲")
            .setMessage("遊戲尚未結束，確定要返回主畫面嗎？")
            .setPositiveButton("離開") { _, _ -> finish() }
            .setNegativeButton("繼續玩", null)
            .show()
    }

    /**
     * 更新 UI 上的範圍與次數提示。
     */
    private fun updateUI() {
        tvRange.text = "範圍：$minRange ~ $maxRange"
        etGuess.hint = "輸入 $minRange 到 $maxRange"
        tvAttempts.text = "嘗試次數：$attemptCount"
    }
}