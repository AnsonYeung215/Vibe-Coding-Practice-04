package hk.edu.thei.ict.vibecode3

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * DatabaseHelper 負責管理 App 的 SQLite 資料庫。
 * 包含兩張表：Bingo 紀錄 (bingo_records) 與 猜數字紀錄 (guess_records)。
 */
class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "BingoGame.db"
        // 版本號必須 +1，當資料表結構改變時，系統會觸發 onUpgrade 以重建資料表
        private const val DATABASE_VERSION = 2

        // Bingo 資料表與欄位常數定義
        const val TABLE_BINGO_RECORDS = "bingo_records"
        const val COL_BINGO_ID = "id"
        const val COL_BINGO_USERNAME = "username"
        const val COL_BINGO_ROUND = "round_number"
        const val COL_BINGO_FIVE_NUMBERS = "five_numbers"
        const val COL_BINGO_SYSTEM_TIME = "system_time"

        // 猜數字資料表與欄位常數定義
        const val TABLE_GUESS_RECORDS = "guess_records"
        const val COL_GUESS_ID = "id"
        const val COL_GUESS_USERNAME = "username"
        const val COL_GUESS_TARGET = "target_number"
        const val COL_GUESS_ATTEMPTS = "attempts"
        const val COL_GUESS_SYSTEM_TIME = "system_time"
    }

    /**
     * 資料庫第一次被建立時會呼叫此方法。
     * 在這裡執行 SQL 語法建立兩張資料表。
     */
    override fun onCreate(db: SQLiteDatabase?) {
        // 建立 Bingo 紀錄表
        val createBingoTable = "CREATE TABLE $TABLE_BINGO_RECORDS (" +
                "$COL_BINGO_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COL_BINGO_USERNAME TEXT, " +
                "$COL_BINGO_ROUND INTEGER, " +
                "$COL_BINGO_FIVE_NUMBERS TEXT, " +
                "$COL_BINGO_SYSTEM_TIME TEXT)"
        db?.execSQL(createBingoTable)

        // 建立猜數字紀錄表
        val createGuessTable = "CREATE TABLE $TABLE_GUESS_RECORDS (" +
                "$COL_GUESS_ID INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "$COL_GUESS_USERNAME TEXT, " +
                "$COL_GUESS_TARGET INTEGER, " +
                "$COL_GUESS_ATTEMPTS INTEGER, " +
                "$COL_GUESS_SYSTEM_TIME TEXT)"
        db?.execSQL(createGuessTable)
    }

    /**
     * 當資料庫版本號 (DATABASE_VERSION) 增加時，會呼叫此方法。
     * 這裡直接刪除舊表並重新建立，確保結構是最新的。
     */
    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_BINGO_RECORDS")
        db?.execSQL("DROP TABLE IF EXISTS $TABLE_GUESS_RECORDS")
        onCreate(db)
    }

    /**
     * 新增一筆 Bingo 紀錄到資料庫。
     * @param username 玩家名稱
     * @param roundNumber 第幾局達成
     * @param fiveNumbers 連線的五個數字 (以逗號分隔的字串)
     */
    fun insertBingoRecord(username: String, roundNumber: Int, fiveNumbers: String) {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COL_BINGO_USERNAME, username)
            put(COL_BINGO_ROUND, roundNumber)
            put(COL_BINGO_FIVE_NUMBERS, fiveNumbers)

            // 取得當下系統時間，格式化為 yyyy-MM-dd HH:mm:ss
            val currentTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            put(COL_BINGO_SYSTEM_TIME, currentTime)
        }
        db.insert(TABLE_BINGO_RECORDS, null, values)
        db.close() // 寫入完畢後關閉連線，節省資源
    }

    /**
     * 新增一筆猜數字紀錄到資料庫。
     * @param username 玩家名稱
     * @param targetNumber 該局的目標答案
     * @param attempts 猜測次數
     */
    fun insertGuessRecord(username: String, targetNumber: Int, attempts: Int) {
        val db = this.writableDatabase
        val values = ContentValues().apply {
            put(COL_GUESS_USERNAME, username)
            put(COL_GUESS_TARGET, targetNumber)
            put(COL_GUESS_ATTEMPTS, attempts)

            val currentTime = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(Date())
            put(COL_GUESS_SYSTEM_TIME, currentTime)
        }
        db.insert(TABLE_GUESS_RECORDS, null, values)
        db.close()
    }
}