package hk.edu.thei.ict.vibecode3

import android.database.Cursor
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView

/**
 * HistoryActivity 顯示 Bingo 與猜數字遊戲的歷史紀錄與最佳成績。
 * 使用 Spinner (下拉選單) 切換不同遊戲的紀錄。
 */
class HistoryActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private lateinit var spinner: Spinner
    private lateinit var tvBestRecord: TextView
    private lateinit var llHistoryList: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history)

        dbHelper = DatabaseHelper(this)
        spinner = findViewById(R.id.spinnerGameType)
        tvBestRecord = findViewById(R.id.tvBestRecord)
        llHistoryList = findViewById(R.id.llHistoryList)

        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnBack).setOnClickListener {
            finish()
        }

        // 設定下拉選單的選項
        val gameTypes = arrayOf("🎰 Bingo 遊戲", "🎯 猜數字遊戲")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, gameTypes)
        spinner.adapter = adapter

        // 監聽下拉選單的變化
        spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (position == 0) {
                    loadBingoHistory() // 載入 Bingo 紀錄
                } else {
                    loadGuessHistory() // 載入猜數字紀錄
                }
            }
            override fun onNothingSelected(parent: AdapterView<*>?) {}
        }
    }

    /**
     * 從 SQLite 讀取 Bingo 歷史紀錄並顯示。
     */
    private fun loadBingoHistory() {
        llHistoryList.removeAllViews()
        val db = dbHelper.readableDatabase
        val cursor: Cursor = db.rawQuery("SELECT * FROM ${DatabaseHelper.TABLE_BINGO_RECORDS} ORDER BY ${DatabaseHelper.COL_BINGO_ID} DESC", null)

        var bestRound = Int.MAX_VALUE
        var hasRecord = false

        if (cursor.moveToFirst()) {
            do {
                hasRecord = true
                // 從 Cursor 取出欄位資料
                val username = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_BINGO_USERNAME))
                val round = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_BINGO_ROUND))
                val numbers = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_BINGO_FIVE_NUMBERS))
                val time = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_BINGO_SYSTEM_TIME))

                // 計算最快局數
                if (round < bestRound) bestRound = round

                // 新增卡片到畫面上
                addRecordCard("👤 $username", "第 $round 局", "連線: $numbers", time)
            } while (cursor.moveToNext())
        }
        cursor.close()

        // 更新最佳紀錄文字
        if (hasRecord) {
            tvBestRecord.text = "最快在第 $bestRound 局達成 Bingo！"
        } else {
            tvBestRecord.text = "暫無 Bingo 紀錄"
        }
    }

    /**
     * 從 SQLite 讀取猜數字歷史紀錄並顯示。
     */
    private fun loadGuessHistory() {
        llHistoryList.removeAllViews()
        val db = dbHelper.readableDatabase
        val cursor: Cursor = db.rawQuery("SELECT * FROM ${DatabaseHelper.TABLE_GUESS_RECORDS} ORDER BY ${DatabaseHelper.COL_GUESS_ID} DESC", null)

        var bestAttempts = Int.MAX_VALUE
        var bestTarget = 0
        var hasRecord = false

        if (cursor.moveToFirst()) {
            do {
                hasRecord = true
                val username = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_GUESS_USERNAME))
                val target = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_GUESS_TARGET))
                val attempts = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_GUESS_ATTEMPTS))
                val time = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_GUESS_SYSTEM_TIME))

                // 計算最少猜測次數
                if (attempts < bestAttempts) {
                    bestAttempts = attempts
                    bestTarget = target
                }

                addRecordCard("👤 $username", "答案: $target", "猜測次數: $attempts 次", time)
            } while (cursor.moveToNext())
        }
        cursor.close()

        if (hasRecord) {
            tvBestRecord.text = "以最少 $bestAttempts 次猜中答案 $bestTarget！"
        } else {
            tvBestRecord.text = "暫無猜數字紀錄"
        }
    }

    /**
     * 動態生成一張歷史紀錄卡片 (CardView)。
     */
    private fun addRecordCard(title: String, subTitle: String, detail: String, time: String) {
        val card = CardView(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(0, 0, 0, 12) } // 卡片底部間距
            radius = 16f // 圓角
            setCardBackgroundColor(Color.WHITE)
            cardElevation = 4f // 陰影
        }

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        // 標題 (使用者名稱)
        val tvTitle = TextView(this).apply {
            text = title
            textSize = 16f
            setTextColor(Color.parseColor("#333333"))
            setTypeface(null, Typeface.BOLD)
        }

        // 副標題 (局數 / 答案)
        val tvSubTitle = TextView(this).apply {
            text = subTitle
            textSize = 14f
            setTextColor(Color.parseColor("#757575"))
            setPadding(0, 8, 0, 0)
        }

        // 詳細資訊 (連線數字 / 猜測次數)
        val tvDetail = TextView(this).apply {
            text = detail
            textSize = 14f
            setTextColor(Color.parseColor("#6200EE"))
            setPadding(0, 4, 0, 0)
        }

        // 系統時間
        val tvTime = TextView(this).apply {
            text = "🕒 $time"
            textSize = 12f
            setTextColor(Color.parseColor("#9E9E9E"))
            setPadding(0, 8, 0, 0)
            gravity = Gravity.END // 靠右對齊
        }

        // 將 TextView 加入 Layout，再將 Layout 加入 CardView
        layout.addView(tvTitle)
        layout.addView(tvSubTitle)
        layout.addView(tvDetail)
        layout.addView(tvTime)
        card.addView(layout)

        // 將卡片加入主畫面列表
        llHistoryList.addView(card)
    }
}