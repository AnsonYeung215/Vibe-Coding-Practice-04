package hk.edu.thei.ict.vibecode3

import android.content.Context

/**
 * PrefsManager 封裝了 SharedPreferences，用於儲存簡單的鍵值對資料 (如登入狀態、玩家名稱、統計數據)。
 */
class PrefsManager(context: Context) {
    private val prefs = context.getSharedPreferences("app_prefs", Context.MODE_PRIVATE)

    // 登入狀態：記錄使用者是否勾選了「記住我」
    var isLoggedIn: Boolean
        get() = prefs.getBoolean("is_logged_in", false)
        set(v) = prefs.edit().putBoolean("is_logged_in", v).apply()

    // 玩家名稱
    var username: String?
        get() = prefs.getString("username", null)
        set(v) = prefs.edit().putString("username", v).apply()

    // 遊戲音效開關狀態
    var soundEnabled: Boolean
        get() = prefs.getBoolean("sound_enabled", true)
        set(v) = prefs.edit().putBoolean("sound_enabled", v).apply()

    // 總遊玩局數
    var gamesPlayed: Int
        get() = prefs.getInt("games_played", 0)
        set(v) = prefs.edit().putInt("games_played", v).apply()

    // 總勝利局數
    var wins: Int
        get() = prefs.getInt("wins", 0)
        set(v) = prefs.edit().putInt("wins", v).apply()

    // 清除所有儲存的資料 (登出時使用)
    fun clearAll() = prefs.edit().clear().apply()
}