package hk.edu.thei.ict.vibecode3

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

/**
 * LoginActivity 負責處理使用者的登入介面。
 * 如果使用者已經登入過 (且勾選記住我)，則直接跳轉到 MainActivity。
 */
class LoginActivity : AppCompatActivity() {
    private lateinit var prefs: PrefsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = PrefsManager(this)

        // 檢查是否已登入，若已登入則直接跳轉
        if (prefs.isLoggedIn) {
            startActivity(Intent(this, MainActivity::class.java))
            finish() // 關閉登入頁，避免使用者按返回鍵又回到登入頁
            return
        }

        setContentView(R.layout.activity_login)

        // 綁定 UI 元件
        val etUser = findViewById<EditText>(R.id.etUsername)
        val etPass = findViewById<EditText>(R.id.etPassword)
        val cbRemember = findViewById<CheckBox>(R.id.cbRemember)
        val tvError = findViewById<TextView>(R.id.tvError)
        val btnLogin = findViewById<Button>(R.id.btnLogin)

        // 登入按鈕點擊事件
        btnLogin.setOnClickListener {
            val user = etUser.text.toString().trim()
            val pass = etPass.text.toString()

            // 驗證輸入是否為空
            if (user.isEmpty() || pass.isEmpty()) {
                tvError.text = "請輸入帳號密碼"
                tvError.visibility = View.VISIBLE
                return@setOnClickListener // 提前結束，不繼續執行
            }
            tvError.visibility = View.GONE

            // 儲存使用者名稱
            prefs.username = user
            // 若勾選記住我，則儲存登入狀態
            if (cbRemember.isChecked) prefs.isLoggedIn = true

            // 跳轉到主畫面
            startActivity(Intent(this, MainActivity::class.java))
            finish()
        }
    }
}