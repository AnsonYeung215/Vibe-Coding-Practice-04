package hk.edu.thei.ict.vibecode3

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.GridLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

/**
 * BingoActivity 實作 Bingo 遊戲的邏輯與 UI 生成。
 */
class BingoActivity : AppCompatActivity() {

    private lateinit var prefs: PrefsManager
    private lateinit var dbHelper: DatabaseHelper

    // 儲存格子的 TextView 清單，方便後續做 Bingo 判定
    private val bingoTextViews = mutableListOf<TextView>()
    private val cardNumbers = mutableListOf<Int>()

    private var currentRound = 1 // 當前局數
    private var hasBingoed = false // 是否已達成 Bingo

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_bingo)

        prefs = PrefsManager(this)
        dbHelper = DatabaseHelper(this)

        val grid = findViewById<GridLayout>(R.id.bingoGrid)
        val btnBack = findViewById<com.google.android.material.button.MaterialButton>(R.id.btnBack)
        val btnCallNumber = findViewById<Button>(R.id.btnCallNumber)
        val btnRestart = findViewById<Button>(R.id.btnRestart)
        val tvCalledNumber = findViewById<TextView>(R.id.tvCalledNumber)
        val tvRoundInfo = findViewById<TextView>(R.id.tvRoundInfo)

        // 初始化 Bingo 格子
        setupBingoGrid(grid, tvRoundInfo)

        tvRoundInfo.text = "第 $currentRound 局"

        // 返回按鈕
        btnBack.setOnClickListener {
            if (hasBingoed) {
                finish() // 已 Bingo，直接返回
            } else {
                showExitConfirmDialog() // 未 Bingo，跳出確認
            }
        }

        // 叫號按鈕 (模擬主持人抽號)
        btnCallNumber.setOnClickListener {
            if (cardNumbers.isEmpty()) return@setOnClickListener
            // 從玩家卡片上的數字隨機抽一個
            val calledNumber = cardNumbers.random()
            tvCalledNumber.text = "叫號: $calledNumber"
            Toast.makeText(this, "主持人叫了: $calledNumber", Toast.LENGTH_SHORT).show()
        }

        // 重新開始按鈕
        btnRestart.setOnClickListener {
            currentRound++
            setupBingoGrid(grid, tvRoundInfo)
            tvRoundInfo.text = "第 $currentRound 局"
            tvCalledNumber.text = "準備開始"
        }
    }

    /**
     * 動態生成 5x5 的 Bingo 格子。
     */
    private fun setupBingoGrid(grid: GridLayout, tvRoundInfo: TextView) {
        grid.removeAllViews()
        bingoTextViews.clear()
        cardNumbers.clear()
        hasBingoed = false

        // 產生 1~25 的數字並打亂
        val numbers = (1..25).toMutableList()
        numbers.shuffle()

        for (i in 0 until 25) {
            val number = numbers[i]
            cardNumbers.add(number)

            // 使用 TextView 模擬按鈕，避免 MaterialButton 排版問題
            val textView = TextView(this).apply {
                text = number.toString()
                textSize = 20f
                gravity = Gravity.CENTER
                setTextColor(Color.parseColor("#333333"))
                setTypeface(null, android.graphics.Typeface.BOLD)

                // 設定圓角背景
                background = GradientDrawable().apply {
                    setColor(Color.parseColor("#E0E0E0"))
                    cornerRadius = 20f
                }

                // 設定可點擊與焦點
                isClickable = true
                isFocusable = true
            }

            // 設定 GridLayout 的排版參數 (平均分配)
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = 0
                rowSpec = GridLayout.spec(i / 5, 1f) // 第幾行
                columnSpec = GridLayout.spec(i % 5, 1f) // 第幾列
                setMargins(6, 6, 6, 6) // 格子間距
            }
            textView.layoutParams = params

            // 點擊格子的事件
            textView.setOnClickListener {
                if (textView.tag != "marked") {
                    // 標記為綠色
                    (textView.background as? GradientDrawable)?.setColor(Color.parseColor("#4CAF50"))
                    textView.setTextColor(Color.WHITE)
                    textView.tag = "marked"
                    checkBingo(tvRoundInfo)
                }
            }

            grid.addView(textView)
            bingoTextViews.add(textView)
        }
    }

    /**
     * 檢查是否達成 Bingo (連線)。
     */
    private fun checkBingo(tvRoundInfo: TextView) {
        if (hasBingoed) return

        // 將一維的 TextView 轉換成二維陣列方便判斷行列
        val matrix = Array(5) { row -> Array(5) { col -> bingoTextViews[row * 5 + col] } }
        var isBingo = false
        var winningNumbers = listOf<Int>()

        // 檢查行 (橫向)
        for (row in 0 until 5) {
            if (matrix[row].all { it.tag == "marked" }) {
                isBingo = true
                winningNumbers = matrix[row].map { it.text.toString().toInt() }
                break
            }
        }
        // 檢查列 (縱向)
        if (!isBingo) {
            for (col in 0 until 5) {
                if ((0 until 5).all { matrix[it][col].tag == "marked" }) {
                    isBingo = true
                    winningNumbers = (0 until 5).map { matrix[it][col].text.toString().toInt() }
                    break
                }
            }
        }
        // 檢查兩條對角線
        if (!isBingo) {
            if ((0 until 5).all { matrix[it][it].tag == "marked" }) {
                isBingo = true
                winningNumbers = (0 until 5).map { matrix[it][it].text.toString().toInt() }
            } else if ((0 until 5).all { matrix[it][4 - it].tag == "marked" }) {
                isBingo = true
                winningNumbers = (0 until 5).map { matrix[it][4 - it].text.toString().toInt() }
            }
        }

        // 若達成 Bingo
        if (isBingo) {
            hasBingoed = true
            val numbersString = winningNumbers.joinToString(", ")

            // 顯示 Bingo 彈窗
            AlertDialog.Builder(this)
                .setTitle("🎉 恭喜 Bingo！")
                .setMessage("你在第 $currentRound 局達成了 Bingo！\n連線數字: $numbersString\n\n要再玩一局嗎？")
                .setCancelable(false)
                .setPositiveButton("再玩一局") { _, _ ->
                    currentRound++
                    setupBingoGrid(findViewById(R.id.bingoGrid), tvRoundInfo)
                    tvRoundInfo.text = "第 $currentRound 局"
                    findViewById<TextView>(R.id.tvCalledNumber).text = "準備開始"
                }
                .setNegativeButton("返回選擇頁") { _, _ -> finish() }
                .show()

            // 寫入資料庫
            val username = prefs.username ?: "訪客"
            dbHelper.insertBingoRecord(username, currentRound, numbersString)
        }
    }

    private fun showExitConfirmDialog() {
        AlertDialog.Builder(this)
            .setTitle("離開遊戲")
            .setMessage("遊戲尚未結束，確定要返回主畫面嗎？")
            .setPositiveButton("離開") { _, _ -> finish() }
            .setNegativeButton("繼續玩", null)
            .show()
    }
}