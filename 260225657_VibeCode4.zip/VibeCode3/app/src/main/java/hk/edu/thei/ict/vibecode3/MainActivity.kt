package hk.edu.thei.ict.vibecode3

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var prefs: PrefsManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = PrefsManager(this)

        // 顯示歡迎詞
        findViewById<TextView>(R.id.tvWelcome).text = "歡迎回來, ${prefs.username ?: "訪客"} 👋"

        // 開始遊戲
        findViewById<Button>(R.id.btnPlay).setOnClickListener {
            startActivity(Intent(this, GameSelectionActivity::class.java))
        }

        // ⭐ 前往歷史紀錄
        findViewById<Button>(R.id.btnHistory).setOnClickListener {
            startActivity(Intent(this, HistoryActivity::class.java))
        }

        // 前往設定
        findViewById<Button>(R.id.btnConfig).setOnClickListener {
            startActivity(Intent(this, ConfigurationActivity::class.java))
        }

        // 登出並清除資料
        findViewById<Button>(R.id.btnLogout).setOnClickListener {
            prefs.clearAll()
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
        }
    }

    // 每次回到首頁時刷新統計數據
    override fun onResume() {
        super.onResume()
        findViewById<TextView>(R.id.tvStats).text =
            "🎯 已玩 ${prefs.gamesPlayed} 局\n🏆 勝利 ${prefs.wins} 局"
    }
}