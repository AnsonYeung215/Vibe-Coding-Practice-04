package hk.edu.thei.ict.vibecode3

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * GameSelectionActivity 讓使用者選擇要玩「猜數字」還是「Bingo」。
 */
class GameSelectionActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_game_selection)

        // 點擊前往猜數字遊戲
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnSelectGuess).setOnClickListener {
            startActivity(Intent(this, GameActivity::class.java))
        }

        // 點擊前往 Bingo 遊戲
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnSelectBingo).setOnClickListener {
            startActivity(Intent(this, BingoActivity::class.java))
        }

        // 返回主畫面
        findViewById<com.google.android.material.button.MaterialButton>(R.id.btnBack).setOnClickListener {
            finish() // finish() 會關閉當前 Activity，回到上一個 (MainActivity)
        }
    }
}